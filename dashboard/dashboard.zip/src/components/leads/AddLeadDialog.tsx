import { useMemo, useState } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import ServiceCatalogPicker from '@/components/ServiceCatalogPicker';
import { DEFAULT_STATE, INDIAN_STATES, citiesForState } from '@/data/indiaLocations';
import { TEMPERATURE_LABELS, TEMPERATURE_STYLES } from '@/data/leadTemperature';
import { useServiceCatalog, type CatalogService } from '@/hooks/useServiceCatalog';
import {
  LEAD_TEMPERATURES,
  LEAD_PRIORITIES,
  useCreateLead,
  type LeadServiceInput,
  type LeadTemperature,
  type LeadPriority,
} from '@/hooks/useLeads';

/* ── Helpers ────────────────────────────────────────────────────────────────── */

const formatDateInput = (date: Date) => {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
};

const todayDateInput = () => formatDateInput(new Date());

const inDays = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return formatDateInput(d);
};

/** Sentinel for "the city I need isn't in the list" — switches to free text. */
const OTHER_CITY = '__other__';

/* ── Form shape ─────────────────────────────────────────────────────────────── */

/** A service on the form, with the dates and status captured alongside it. */
interface DraftService {
  id: string;
  slug: string;
  title: string;
  category: string;
  categorySlug: string;
  startAt: string;
  dueAt: string;
  priority: string;
  temperature: string;
}

interface ClientForm {
  client: string;
  phone: string;
  email: string;
  company: string;
  state: string;
  city: string;
  /** One follow-up for the lead as a whole, whatever they booked. */
  followUpAt: string;
  followUpNote: string;
}

const EMPTY_FORM: ClientForm = {
  client: '', phone: '', email: '', company: '', state: DEFAULT_STATE, city: '',
  followUpAt: '', followUpNote: '',
};

/* ── Dialog ─────────────────────────────────────────────────────────────────── */

interface AddLeadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/**
 * Captures a client and everything they asked for.
 *
 * Each service carries its own start date, target date and status, because a
 * client rarely wants two filings on the same timeline — the marriage
 * registration may be urgent while the trademark can wait a quarter.
 */
export function AddLeadDialog({ open, onOpenChange }: AddLeadDialogProps) {
  const defaultService = () => ({
    id: crypto.randomUUID(),
    slug: '',
    title: '',
    category: '',
    categorySlug: '',
    startAt: todayDateInput(),
    dueAt: inDays(30),
    priority: 'MEDIUM',
    temperature: 'WARM',
  });

  const [form, setForm] = useState<ClientForm>(EMPTY_FORM);
  const [services, setServices] = useState<DraftService[]>([defaultService()]);
  const { data: catalog } = useServiceCatalog();
  const [cityIsFreeText, setCityIsFreeText] = useState(false);

  const createLead = useCreateLead();

  const cities = useMemo(() => citiesForState(form.state), [form.state]);

  const update = <K extends keyof ClientForm>(field: K, value: ClientForm[K]) =>
    setForm((current) => ({ ...current, [field]: value }));

  // A city only means something within its state, so changing the state clears it.
  const handleStateChange = (state: string) => {
    setForm((current) => ({ ...current, state, city: '' }));
    setCityIsFreeText(citiesForState(state).length === 0);
  };

  const handleCityChange = (value: string) => {
    if (value === OTHER_CITY) {
      setCityIsFreeText(true);
      update('city', '');
      return;
    }
    update('city', value);
  };

  const addServiceRow = () => {
    setServices((current) => [
      ...current,
      defaultService(),
    ]);
  };

  const updateService = <K extends keyof DraftService>(id: string, field: K, value: DraftService[K]) => {
    setServices((current) =>
      current.map((service) => (service.id === id ? { ...service, [field]: value } : service))
    );
  };

  const handleServiceSelect = (id: string, slug: string) => {
    const s = catalog?.services.find((x) => x.slug === slug);
    if (!s) return;
    setServices((current) =>
      current.map((service) =>
        service.id === id
          ? { ...service, slug: s.slug, title: s.title, category: s.category, categorySlug: s.categorySlug }
          : service
      )
    );
  };

  const removeService = (id: string) =>
    setServices((current) => current.filter((service) => service.id !== id));

  const reset = () => {
    setForm(EMPTY_FORM);
    setServices([defaultService()]);
    setCityIsFreeText(false);
  };

  const handleSubmit = () => {
    const client = form.client.trim();
    const phone = form.phone.trim();

    if (!client || !phone) {
      toast.error('Client name and phone number are required.');
      return;
    }

    const dated = services.filter((service) => service.startAt && service.dueAt && service.slug);
    const outOfOrder = dated.find((service) => service.dueAt < service.startAt);
    if (outOfOrder) {
      toast.error(`${outOfOrder.title || 'A service'}: the target date can't be before the start date.`);
      return;
    }

    const payload: LeadServiceInput[] = services
      .filter((s) => s.slug)
      .map((service) => ({
        title: service.title,
        slug: service.slug,
        category: service.category,
        categorySlug: service.categorySlug,
        startAt: service.startAt ? new Date(`${service.startAt}T00:00:00`).toISOString() : undefined,
        dueAt: service.dueAt ? new Date(`${service.dueAt}T23:59:00`).toISOString() : undefined,
        temperature: service.temperature as LeadTemperature,
      }));

    createLead.mutate(
      {
        name: client,
        phone,
        email: form.email.trim() || undefined,
        company: form.company.trim() || undefined,
        state: form.state || undefined,
        city: form.city.trim() || undefined,
        services: payload,
        serviceStage: 'documents_pending',
        status: 'NEW',
        source: 'manual',
        followUpAt: form.followUpAt || undefined,
        followUpNote: form.followUpNote.trim() || undefined,
      },
      {
        onSuccess: () => {
          onOpenChange(false);
          reset();
          toast.success(
            services.length > 0
              ? `Lead added — ${client} wants ${services.length} service${services.length === 1 ? '' : 's'}.`
              : `Lead added for ${client}.`
          );
        },
        onError: (err: Error) => toast.error(err?.message || 'Failed to add lead.'),
      }
    );
  };

  return (
    <>
      <Dialog
        open={open}
        onOpenChange={(next) => { onOpenChange(next); if (!next) reset(); }}
      >
        <DialogContent className="max-w-3xl p-0 overflow-hidden">
          <DialogHeader className="px-6 pt-4 pb-2 border-b border-border">
            <DialogTitle>Add Lead</DialogTitle>
          </DialogHeader>
          <div className="px-6 py-2 space-y-4 max-h-[85vh] overflow-y-auto">
            {/* ── Who they are ──────────────────────────────────────────────── */}
            <section className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="lead-client">Client name *</Label>
                  <Input
                    id="lead-client"
                    value={form.client}
                    onChange={(e) => update('client', e.target.value)}
                    placeholder="Full name of the client"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lead-phone">Phone *</Label>
                  <Input
                    id="lead-phone"
                    value={form.phone}
                    onChange={(e) => update('phone', e.target.value)}
                    placeholder="+91…"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="lead-email">Email</Label>
                <Input
                  id="lead-email"
                  type="email"
                  value={form.email}
                  onChange={(e) => update('email', e.target.value)}
                  placeholder="client@example.com"
                />
              </div>
            </section>

            {/* ── Where they are ────────────────────────────────────────────── */}
            <section className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label htmlFor="lead-company">Company</Label>
                <Input
                  id="lead-company"
                  value={form.company}
                  onChange={(e) => update('company', e.target.value)}
                  placeholder="Optional"
                />
              </div>

              <div className="space-y-2">
                <Label>State</Label>
                <Select value={form.state} onValueChange={handleStateChange}>
                  <SelectTrigger><SelectValue placeholder="Select state" /></SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    {INDIAN_STATES.map((state) => (
                      <SelectItem key={state} value={state}>{state}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="lead-city">City</Label>
                {cityIsFreeText || cities.length === 0 ? (
                  <div className="flex items-center gap-1.5">
                    <Input
                      id="lead-city"
                      value={form.city}
                      onChange={(e) => update('city', e.target.value)}
                      placeholder="Type the city"
                    />
                    {cities.length > 0 && (
                      <button
                        type="button"
                        onClick={() => { setCityIsFreeText(false); update('city', ''); }}
                        title="Back to the city list"
                        className="shrink-0 h-9 px-2 rounded-md border border-border text-muted-foreground hover:bg-muted"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ) : (
                  <Select value={form.city} onValueChange={handleCityChange}>
                    <SelectTrigger>
                      <SelectValue placeholder={`Select city in ${form.state}`} />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {cities.map((city) => (
                        <SelectItem key={city} value={city}>{city}</SelectItem>
                      ))}
                      <SelectItem value={OTHER_CITY}>Other…</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              </div>
            </section>

            {/* ── What they want ────────────────────────────────────────────── */}
            <section>
              <div className="flex items-center justify-between gap-3 mb-3">
                <div>
                  <Label>Services</Label>
                </div>
              </div>

              <div className="space-y-2 overflow-x-auto">
                <div className="min-w-[600px]">
                  <div
                    className="grid gap-2 mb-1"
                    style={{ gridTemplateColumns: 'minmax(0, 4fr) minmax(0, 2fr) minmax(0, 3fr) minmax(0, 3fr) minmax(0, 2fr) 28px' }}
                  >
                    <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Select Service</div>
                    <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Priority</div>
                    <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">When to Start</div>
                    <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Target Date</div>
                    <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Status</div>
                    <div></div>
                  </div>

                  {services.map((service) => (
                    <div
                      key={service.id}
                      className="grid gap-2 items-center mb-2"
                      style={{ gridTemplateColumns: 'minmax(0, 4fr) minmax(0, 2fr) minmax(0, 3fr) minmax(0, 3fr) minmax(0, 2fr) 28px' }}
                    >
                      <Select value={service.slug} onValueChange={(val) => handleServiceSelect(service.id, val)}>
                        <SelectTrigger className="h-9 text-xs">
                          <SelectValue placeholder="Select..." />
                        </SelectTrigger>
                        <SelectContent>
                          {catalog?.services.map((s) => (
                            <SelectItem key={s.slug} value={s.slug} className="text-xs">{s.title}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Select value={service.priority} onValueChange={(val) => updateService(service.id, 'priority', val as LeadPriority)}>
                        <SelectTrigger className="h-9 text-xs">
                          <SelectValue placeholder="Priority" />
                        </SelectTrigger>
                        <SelectContent>
                          {LEAD_PRIORITIES.map((p) => (
                            <SelectItem key={p} value={p} className="text-xs">{p}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Input
                        type="date"
                        value={service.startAt}
                        onChange={(e) => updateService(service.id, 'startAt', e.target.value)}
                        className="h-9 text-xs"
                      />

                      <Input
                        type="date"
                        min={service.startAt || undefined}
                        value={service.dueAt}
                        onChange={(e) => updateService(service.id, 'dueAt', e.target.value)}
                        className="h-9 text-xs"
                      />

                      <Select value={service.temperature} onValueChange={(val) => updateService(service.id, 'temperature', val as LeadTemperature)}>
                        <SelectTrigger className="h-9 text-xs">
                          <SelectValue placeholder="Status" />
                        </SelectTrigger>
                        <SelectContent>
                          {LEAD_TEMPERATURES.map((t) => (
                            <SelectItem key={t} value={t} className="text-xs">{t}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <button
                        type="button"
                        onClick={() => removeService(service.id)}
                        className="shrink-0 h-9 w-7 rounded-md text-destructive hover:bg-destructive/10 flex items-center justify-center"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}

                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addServiceRow}
                    className="mt-2"
                  >
                    <Plus className="w-4 h-4 mr-1.5" />
                    Add Service
                  </Button>
                </div>
              </div>
            </section>

            {/* ── When to chase them ────────────────────────────────────────── */}
            <section className="space-y-3">
              <div>
                <Label>Follow-up</Label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-[minmax(0,200px)_minmax(0,1fr)] gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="lead-followup" className="text-[11px]">Follow-up date</Label>
                  <Input
                    id="lead-followup"
                    type="date"
                    min={todayDateInput()}
                    value={form.followUpAt}
                    onChange={(e) => update('followUpAt', e.target.value)}
                    className="h-9"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="lead-followup-note" className="text-[11px]">Follow-up note</Label>
                  <textarea
                    id="lead-followup-note"
                    value={form.followUpNote}
                    onChange={(e) => update('followUpNote', e.target.value)}
                    className="w-full min-h-[38px] h-9 rounded-md border border-border bg-card px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                </div>
              </div>
            </section>
          </div>

          <DialogFooter className="px-6 py-4 border-t border-border">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button
              onClick={handleSubmit}
              disabled={!form.client.trim() || !form.phone.trim() || createLead.isPending}
            >
              {createLead.isPending ? 'Adding…' : 'Add Lead'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </>
  );
}

export default AddLeadDialog;
